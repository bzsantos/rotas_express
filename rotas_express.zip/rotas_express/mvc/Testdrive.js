import Crud from './Crud.js'


function salvar(){

const crud = new Crud()

let car = {"carsname":"Inpala","color":"red","age":1977}

crud.save(car, function(car){
    console.log("Salvo no Banco de Dados!")

})

}


salvar()
