create DATABASE auto;
use auto;

create table cars(
    id int AUTO_INCREMENT not null,
    carsname VARCHAR(50) null,
    color VARCHAR(30) null,
    age INT null,
    PRIMARY KEY(id)
);

select * from cars;